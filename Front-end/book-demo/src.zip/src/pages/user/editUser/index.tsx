import React from "react";
import { Typography } from "@material-ui/core";

const EditUser = () => {
    return (
        <>
            <Typography variant="h1">EditUser</Typography>
        </>
    );
};

export default EditUser;
