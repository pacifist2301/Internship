import React from "react";
import { Typography } from "@material-ui/core";

const User = () => {
    return (
        <>
            <Typography variant="h1">User</Typography>
        </>
    );
};

export default User;
