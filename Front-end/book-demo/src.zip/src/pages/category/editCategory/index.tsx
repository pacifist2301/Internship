import React from "react";
import { Typography } from "@material-ui/core";

const EditCategory = () => {
    return (
        <>
            <Typography variant="h1">EditCategory</Typography>
        </>
    );
};

export default EditCategory;
