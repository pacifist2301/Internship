import React from "react";
import { Typography } from "@material-ui/core";

const Category = () => {
    return (
        <>
            <Typography variant="h1">Category</Typography>
        </>
    );
};

export default Category;
